/* SCORM 1.2 API wrapper — auto-injected by scorm_pack.py */
(function () {
  var _api = null;
  var _ready = false;

  function _findAPI(win) {
    var depth = 0;
    while (!win.API && win.parent && win.parent !== win) {
      if (++depth > 7) return null;
      win = win.parent;
    }
    return win.API || null;
  }

  function _getAPI() {
    var api = _findAPI(window);
    if (!api && window.opener) api = _findAPI(window.opener);
    return api;
  }

  var SCORM = {
    init: function () {
      _api = _getAPI();
      if (!_api) { console.warn("[SCORM] LMS API not found — running outside LMS"); return false; }
      var r = _api.LMSInitialize("");
      _ready = (r === "true" || r === true);
      if (!_ready) console.warn("[SCORM] LMSInitialize() returned false");
      return _ready;
    },

    set: function (key, value) {
      if (!_ready) return;
      _api.LMSSetValue(key, String(value));
    },

    get: function (key) {
      if (!_ready) return "";
      return _api.LMSGetValue(key);
    },

    commit: function () {
      if (!_ready) return;
      _api.LMSCommit("");
    },

    finish: function () {
      if (!_ready) return;
      _api.LMSCommit("");
      _api.LMSFinish("");
      _ready = false;
    },

    /* One-call shortcut — use on your "Завершить" button */
    complete: function () {
      this.set("cmi.core.lesson_status", "passed");
      this.set("cmi.core.score.raw",     "100");
      this.set("cmi.core.score.min",     "0");
      this.set("cmi.core.score.max",     "100");
      this.set("cmi.core.exit",          "normal");
      this.finish();
    }
  };

  window.addEventListener("load",         function () { SCORM.init(); });
  window.addEventListener("beforeunload", function () { SCORM.finish(); });

  window.SCORM = SCORM;
})();
